#' TF-gene binding DB metadata
#'
#' A data frame containing information of the ChIP-Seq experiments used to build the TF-gene binding DB.
#' Fields in the data frame:
#' \itemize{
#'   \item Name. Name of the file.
#'   \item Accession. Accesion ID of the experiment.
#'   \item Cell. Cell line or tissue.
#'   \item Cell.Type. More information about the cells.
#'   \item Treatment.
#'   \item Antibody.
#'   \item TF. Transcription factor tested in the ChIP-Seq experiment.
#' }
#'
#' @docType data
#' @keywords datasets
#' @name MetaData
#' @usage data(MetaData)
#' @format a list of 1129 arrays
"MetaData"

#' TF-gene binding binary matrix
#'
#' Its rows correspond to all the human genes that have been assigned an Entrez ID, and its columns, to every ChIP-Seq experiment in the database.
#' The values are 1 – if the ChIP-Seq has a peak assigned to that gene – or 0 – if it hasn’t –.
#'
#' @docType data
#' @keywords datasets
#' @name Mat01
#' @usage data(Mat01)
#' @format a matrix of 1129 columns and 23056 rows
"Mat01"

#' RNA-Seq experiment
#'
#' A data frame containing information of of an RNA-Seq experiment on newly transcripted RNA in HUVEC cells during
#' two conditions, 8h of normoxia and 8h of hypoxia. The data frame contains the following fields:
#' \itemize{
#'   \item Gene (factor): Gene Symbol for each gene analyzed.
#'   \item Log2FoldChange: base 2 logarithm of the fold change on RNA transcription for a given gene between the two conditions.
#'   \item pvalue
#'   \item padj: p-value adjusted via FDR.
#' }
#'
#' @docType data
#' @keywords datasets
#' @name hypoxia
#' @usage data(hypoxia)
#' @format a data frame of 17527 observations of 4 variables.
"hypoxia"
