## ----eval=TRUE, echo=T---------------------------------------------------
data("hypoxia",package = "TFEA.ChIP")  #load hypoxia dataset
head(hypoxia) #shows first rows of the hypoxia dataset

## ----eval=TRUE, echo=T---------------------------------------------------
Genes.Upreg <- hypoxia[which(hypoxia$log2FoldChange > 1 & hypoxia$padj <= 0.05),"Gene"]   #extract vector with names of upregulated genes
Genes.Control <- hypoxia[which(abs(hypoxia$log2FoldChange) < 0.25 & hypoxia$padj > 0.5),"Gene"]   #extract vector with names of non-responsive genes

## ----eval=TRUE, echo=T,message=FALSE-------------------------------------
library(TFEA.ChIP)
#Conversion of hgnc to ENTREZ IDs
Genes.Upreg <- GeneID2entrez(Genes.Upreg)
Genes.Control <- GeneID2entrez(Genes.Control)

## ----eval=TRUE, echo=T---------------------------------------------------
CM_list_UP <- contingency_matrix(Genes.Upreg,Genes.Control) #generates list of contingency tables, one per dataset
pval_mat_UP <- getCMstats(CM_list_UP) #generates list of p-values and OR from association test
head(pval_mat_UP)

## ----eval=TRUE, echo=T---------------------------------------------------
chip_index<-get_chip_index("encode") #selects ENCODE datasets only
CM_list_UPe <- contingency_matrix(Genes.Upreg,Genes.Control,chip_index) #generates list of contingency tables
pval_mat_UPe <- getCMstats(CM_list_UPe,chip_index) #generates list of p-values and ORs
head(pval_mat_UPe)

## ----eval=FALSE, echo=T--------------------------------------------------
#  plot_CM(pval_mat_UP) #plot p-values against ORs

## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  HIFs<-c("EPAS1","HIF1A","ARNT")
#  names(HIFs)<-c("EPAS1","HIF1A","ARNT")
#  col<-c("red","blue","green")
#  plot_CM(pval_mat_UP,specialTF = HIFs,TF_colors = col) #plot p-values against ORs highlighting indicated TFs

## ----eval=TRUE, echo=T---------------------------------------------------
genes <- GeneID2entrez(hypoxia$Gene,return.Matrix = T) #Conversion of hgnc to ENTREZ IDs
hypoxia.sorted<-merge(hypoxia,genes,by.x=c("Gene"),by.y=c("GENE.ID"),all.x=T) #create new data table including ENTREZ ID
hypoxia.sorted<-hypoxia.sorted[order(-hypoxia.sorted$log2FoldChange),] #sort genes according to fold induction
hypoxia.sorted<-hypoxia.sorted[!is.na(hypoxia.sorted$ENTREZ.ID),] #removes entries not matching an ENTREZ ID

## ----eval=TRUE, echo=T---------------------------------------------------
chip_index<-get_chip_index(TFfilter = c("HIF1A","EPAS1","ARNT")) #restrict the analysis to datasets assaying these factors

## ----eval=TRUE, echo=T---------------------------------------------------
GSEA.result <- GSEA_run(hypoxia.sorted$ENTREZ.ID,chip_index,get.RES = T) #run GSEA analysis
head(GSEA.result$Enrichment.table)
head(GSEA.result$RES$GSM2390642)
head(GSEA.result$indicators$GSM2390642)

## ----eval=FALSE, echo=T--------------------------------------------------
#  TF.hightlight<-c("EPAS1","ARNT")
#  names(TF.hightlight)<-c("EPAS1","ARNT")
#  col<- c("red","blue")
#  plot_ES(GSEA.result,LFC = hypoxia.sorted$log2FoldChange,specialTF = TF.hightlight,TF_colors = col)

## ----eval=FALSE, echo=T--------------------------------------------------
#  plot_RES(GSEA_result = GSEA.result,LFC = Arranged.Genes$log2FoldChange,TF=c("EPAS1"),Accession=c("GSM2390642","GSM1642766"))

## ----eval=FALSE, echo=T--------------------------------------------------
#  folder<-"~/peak.files.folder"
#  File.list<-dir(folder)
#  format<-"macs"

## ----eval=FALSE, echo=T--------------------------------------------------
#  for (i in 1:length(File.list)){
#  
#      tmp<-read.table(file=paste0(folder,"/",File.list[i]), ...)
#  
#      for (j in 1:length(MetaData$Name)){
#          if (File.list[i]==MetaData$Name[j]){
#              file.metadata<-MetaData[j,]
#              break
#          }
#      }
#  
#      txt2GR(tmp, format, GR.folder, file.metadata)
#  }

## ----eval=FALSE, echo=T--------------------------------------------------
#  dnaseClusters<-read.table(file="~/path.to.file.txt",
#                            header = T,sep="\t",stringsAsFactors = F)
#  dnaseClusters<-makeGRangesFromDataFrame(dnaseClusters,
#                           ignore.strand=T,
#                           seqnames.field="chrom",
#                           start.field="chromStart",
#                           end.field="chromEnd")

## ----eval=FALSE, echo=T--------------------------------------------------
#  txdb<-TxDb.Hsapiens.UCSC.hg19.knownGene
#  Genes<-genes(txdb)
#  
#  near.gene<-distanceToNearest(dnaseClusters,Genes)
#  near.gene<-near.gene[!is.na(near.gene@elementMetadata@listData$distance)]
#  near.gene<-near.gene[near.gene@elementMetadata@listData$distance<1000]
#  
#  dnase.sites.list<-queryHits(near.gene)
#  near.gene<-subjectHits(near.gene)
#  
#  DnaseHSites<-GRanges()
#  
#  for (i in 1:length(dnase.sites.list)){
#      tmp<-dnaseClusters[dnase.sites.list[i]]
#      mcols(tmp)$gene_id<-Genes[as.integer(near.gene[i])]$gene_id
#      DnaseHSites<-c(DnaseHSites,tmp)
#  }

## ----eval=FALSE, echo=T--------------------------------------------------
#  load("~/path.to.DnaseHS")
#  ListGR<-dir("~/path.to.GR.files")
#  TF.gene.binding.db<-GR2tfbs_db(DnaseHS,ListGR,GRfolder="~/path.to.GR.files")

## ----eval=FALSE, echo=T--------------------------------------------------
#  
#  txdb<-TxDb.Hsapiens.UCSC.hg19.knownGene
#  gen.list<-genes(txdb)$gene_id # selecting all the genes in knownGene
#  
#  myTFBSmatrix<-makeTFBSmatrix(gen,TF.gene.binding.db)
#  

## ----eval=FALSE, echo=T--------------------------------------------------
#  set_user_data(binary_matrix = myTFBSmatrix, metadada = MetaData)

