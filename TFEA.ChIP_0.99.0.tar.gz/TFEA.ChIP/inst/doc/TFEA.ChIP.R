## ----eval=TRUE,echo=TRUE-------------------------------------------------
library(TFEA.ChIP)
data("deseq.result",package="TFEA.ChIP") # load toy example of a DESeqResults object
dataTable<-deseq2table(deseq.result)
head(dataTable)

## ----eval=TRUE,echo=TRUE-------------------------------------------------
data("hypoxia",package = "TFEA.ChIP")  #load hypoxia dataset
head(hypoxia) #shows first rows of the hypoxia dataset

## ----eval=TRUE,echo=TRUE-------------------------------------------------
Genes.Upreg <- hypoxia[which(hypoxia$log2FoldChange > 1 & hypoxia$padj <= 0.05),"Gene"]   #extract vector with names of upregulated genes
Genes.Control <- hypoxia[which(abs(hypoxia$log2FoldChange) < 0.25 & hypoxia$padj > 0.5),"Gene"]   #extract vector with names of non-responsive genes

## ----eval=TRUE,echo=TRUE,message=FALSE-----------------------------------
#Conversion of hgnc to ENTREZ IDs
Genes.Upreg <- GeneID2entrez(Genes.Upreg)
Genes.Control <- GeneID2entrez(Genes.Control)

## ----eval=TRUE,echo=TRUE-------------------------------------------------
CM_list_UP <- contingency_matrix(Genes.Upreg,Genes.Control) #generates list of contingency tables, one per dataset
pval_mat_UP <- getCMstats(CM_list_UP) #generates list of p-values and OR from association test
head(pval_mat_UP)

## ----eval=TRUE,echo=TRUE-------------------------------------------------
chip_index<-get_chip_index("encode") #selects ENCODE datasets only
CM_list_UPe <- contingency_matrix(Genes.Upreg,Genes.Control,chip_index) #generates list of contingency tables
pval_mat_UPe <- getCMstats(CM_list_UPe,chip_index) #generates list of p-values and ORs
head(pval_mat_UPe)

## ----eval=FALSE,echo=TRUE------------------------------------------------
#  plot_CM(pval_mat_UP) #plot p-values against ORs

## ----eval=TRUE,echo=FALSE,fig.height=4,fig.width=7-----------------------
if("ggplot2" %in% rownames(installed.packages()) == TRUE){ 
    # If ggplot2 is installed, the vignette will include static plots
    # as an example of those generated with plot_CM, plot_ES, and plot_RES
    requireNamespace("ggplot2")
    
    pval_mat_UP$highlight<-rep("Other",length(pval_mat_UP$Accession))
    
    ggplot2::ggplot(pval_mat_UP,ggplot2::aes(x=log.adj.pVal, y=OR))+
        ggplot2::geom_point(ggplot2::aes(col=highlight))+
        ggplot2::labs(title="Transcription factor enrichment", subtitle="HUVEC cells under hypoxia",
             y="Odds Ratio", x="log10(p-value)",
             caption="To limit this file's size, only static versions of the plots are shown in this vignette")+
        ggplot2::theme_bw()+
        ggplot2::scale_color_manual(values = c("Other"="lightsteelblue3"))+
        ggplot2::theme(legend.position="none")
}

## ----eval=FALSE,echo=TRUE------------------------------------------------
#  HIFs<-c("EPAS1","HIF1A","ARNT")
#  names(HIFs)<-c("EPAS1","HIF1A","ARNT")
#  col<-c("red","blue","green")
#  plot_CM(pval_mat_UP,specialTF = HIFs,TF_colors = col) #plot p-values against ORs highlighting indicated TFs

## ----eval=TRUE,echo=FALSE,fig.height=4,fig.width=7-----------------------
if("ggplot2" %in% rownames(installed.packages()) == TRUE){ 
    # If ggplot2 is installed, the vignette will include static plots
    # as an example of those generated with plot_CM, plot_ES, and plot_RES
    
    pval_mat_UP$highlight<-rep("Other",length(pval_mat_UP$Accession))
    pval_mat_UP[pval_mat_UP$TF=="HIF1A"|pval_mat_UP$TF=="EPAS1"|pval_mat_UP$TF=="ARNT",]$highlight<-"HIF"
    pval_mat_UP<-arrange(pval_mat_UP,desc(highlight))
    ggplot2::ggplot(pval_mat_UP,ggplot2::aes(x=log.adj.pVal, y=OR))+
        ggplot2::geom_point(ggplot2::aes(col=highlight))+
        ggplot2::labs(title="Transcription factor enrichment", subtitle="HUVEC cells under hypoxia",
             y="Odds Ratio", x="log10(p-value)",
             caption="To limit this file's size, only static versions of the plots are shown in this vignette")+
        ggplot2::theme_bw()+
        ggplot2::scale_color_manual(name="TF",
            values = c("Other"="lightsteelblue3",
                                      "HIF"="red"))
}

## ----eval=TRUE,echo=TRUE,message=FALSE-----------------------------------
genes <- GeneID2entrez(hypoxia$Gene,return.Matrix = TRUE) #Conversion of hgnc to ENTREZ IDs
hypoxia.sorted<-merge(hypoxia,genes,by.x=c("Gene"),by.y=c("GENE.ID"),all.x=TRUE) #create new data table including ENTREZ ID
hypoxia.sorted<-hypoxia.sorted[order(-hypoxia.sorted$log2FoldChange),] #sort genes according to fold induction
hypoxia.sorted<-hypoxia.sorted[!is.na(hypoxia.sorted$ENTREZ.ID),] #removes entries not matching an ENTREZ ID

## ----eval=TRUE,echo=TRUE-------------------------------------------------
chip_index<-get_chip_index(TFfilter = c("HIF1A","EPAS1","ARNT")) #restrict the analysis to datasets assaying these factors

## ----eval=TRUE,echo=TRUE-------------------------------------------------
GSEA.result <- GSEA_run(hypoxia.sorted$ENTREZ.ID,chip_index,get.RES = TRUE) #run GSEA analysis
head(GSEA.result$Enrichment.table)
head(GSEA.result$RES$GSM2390642)
head(GSEA.result$indicators$GSM2390642)

## ----eval=FALSE,echo=TRUE------------------------------------------------
#  TF.hightlight<-c("EPAS1","ARNT")
#  names(TF.hightlight)<-c("EPAS1","ARNT")
#  col<- c("red","blue")
#  plot_ES(GSEA.result,LFC = hypoxia.sorted$log2FoldChange,specialTF = TF.hightlight,TF_colors = col)

## ----eval=TRUE,echo=FALSE,fig.height=4,fig.width=7-----------------------
if("ggplot2" %in% rownames(installed.packages()) == TRUE){ 
    # If ggplot2 is installed, the vignette will include static plots
    # as an example of those generated with plot_CM, plot_ES, and plot_RES
    table<-GSEA.result$Enrichment.table
    table$highlight<-rep("Other",length(table$Accession))
    table[table$TF=="EPAS1",]$highlight<-"EPAS1"
    table[table$TF=="ARNT",]$highlight<-"ARNT"
    table<-arrange(table,desc(highlight))

    ggplot2::ggplot(table,ggplot2::aes(x=Arg.ES, y=ES))+
        ggplot2::geom_point(ggplot2::aes(col=highlight))+
        ggplot2::labs(title="Transcription factor enrichment", subtitle="HUVEC cells under hypoxia",
             y="Enrichment score", x="Argument",
             caption="To limit this file's size, only static versions of the plots are shown in this vignette")+
        ggplot2::theme_bw()+
        ggplot2::scale_color_manual(name="TF",
                           values = c("Other"="lightsteelblue3",
                                      "EPAS1"="red",
                                      "ARNT"="blue"))+
        ggplot2::geom_hline(yintercept = 0)
}

## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  plot_RES(GSEA_result = GSEA.result,LFC = hypoxia.sorted$log2FoldChange,TF=c("EPAS1"),Accession=c("GSM2390642","GSM1642766"))

## ----eval=TRUE,echo=FALSE,fig.height=4,fig.width=7-----------------------
if("ggplot2" %in% rownames(installed.packages()) == TRUE & "tidyr" %in% rownames(installed.packages()) == TRUE){ 
    # If ggplot2 and tydyr are installed, the vignette will include static plots
    # as an example of those generated with plot_CM, plot_ES, and plot_RES

    table<-data.frame(
        argument=c(1:length(GSEA.result$RES[[1]])),
        GSM2390642=GSEA.result$RES[["GSM2390642"]],
        GSM1642766=GSEA.result$RES[["GSM1642766"]]
    )
    table %>%
        tidyr::gather(Accesion,value, GSM2390642, GSM1642766) %>%
        ggplot2::ggplot(ggplot2::aes(x=argument, y=value, colour=Accesion)) +
        ggplot2::geom_line()+
        ggplot2::labs(title="Running Enrichment Scores", subtitle="HUVEC cells under hypoxia",
             y="RES", x="Argument",
             caption="To limit this file's size, only static versions of the plots are shown in this vignette")+
        ggplot2::theme_bw()+
        ggplot2::geom_hline(yintercept = 0)
}

## ----eval=FALSE,echo=TRUE------------------------------------------------
#  folder<-"~/peak.files.folder"
#  File.list<-dir(folder)
#  format<-"macs"
#  
#  gr.list<-list()
#  for (i in 1:length(File.list)){
#  
#      tmp<-read.table(..., stringsAsFactors = FALSE)
#  
#      for (j in 1:length(myMetaData$Name)){     # Select the metadata corresponding to each dataset.
#          if (File.list[i]==myMetaData$Name[j]){
#              file.metadata<-myMetaData[j,]
#              break
#          }
#      }
#  
#      ChIP.dataset.gr<-txt2GR(tmp, format, file.metadata)
#      gr.list<-c(gr.list,list(ChIP.dataset.gr))
#  }

## ----eval=TRUE,echo=TRUE-------------------------------------------------
# As an example of the output
data("ARNT.peaks.bed","ARNT.metadata",package = "TFEA.ChIP") # Loading example datasets for this function
ARNT.gr<-txt2GR(ARNT.peaks.bed,"macs",ARNT.metadata)
head(ARNT.gr,n=2)

## ----eval=FALSE,echo=TRUE------------------------------------------------
#  dnaseClusters<-read.table(file="~/path.to.file.txt",
#                            header = TRUE,sep="\t",stringsAsFactors = FALSE)
#  dnaseClusters<-makeGRangesFromDataFrame(dnaseClusters,
#                           ignore.strand=TRUE,
#                           seqnames.field="chrom",
#                           start.field="chromStart",
#                           end.field="chromEnd")

## ----eval=FALSE,echo=TRUE------------------------------------------------
#  txdb<-TxDb.Hsapiens.UCSC.hg19.knownGene
#  Genes<-genes(txdb)
#  
#  near.gene<-distanceToNearest(dnaseClusters,Genes)
#  near.gene<-near.gene[!is.na(near.gene@elementMetadata@listData$distance)]
#  near.gene<-near.gene[near.gene@elementMetadata@listData$distance<1000]
#  
#  dnase.sites.list<-queryHits(near.gene)
#  near.gene<-subjectHits(near.gene)
#  
#  DHS.database<-GRanges()
#  
#  for (i in 1:length(dnase.sites.list)){
#      tmp<-dnaseClusters[dnase.sites.list[i]]
#      mcols(tmp)$gene_id<-Genes[as.integer(near.gene[i])]$gene_id
#      DHS.database<-c(DHS.database,tmp)
#  }

## ----eval=TRUE,echo=TRUE-------------------------------------------------
data("DnaseHS_db","gr.list", package="TFEA.ChIP") # Loading example datasets for this function
TF.gene.binding.db<-GR2tfbs_db(DnaseHS_db,gr.list) 
str(TF.gene.binding.db)

## ----eval=TRUE,echo=TRUE-------------------------------------------------
library(TxDb.Hsapiens.UCSC.hg19.knownGene)
data("gr.list", package="TFEA.ChIP") # Loading example datasets for this function
txdb<-TxDb.Hsapiens.UCSC.hg19.knownGene
Genes<-genes(txdb)
TF.gene.binding.db<-GR2tfbs_db(Genes,gr.list) 

## ----eval=TRUE,echo=TRUE-------------------------------------------------
data("tfbs.database",package = "TFEA.ChIP") # Loading example datasets for this function
txdb<-TxDb.Hsapiens.UCSC.hg19.knownGene
gen.list<-genes(txdb)$gene_id # selecting all the genes in knownGene

myTFBSmatrix<-makeTFBSmatrix(gen.list,tfbs.database)
myTFBSmatrix[2530:2533,1:3] # The gene HMGN4 (Entrez ID 10473) has TFBS for this three ChIP-Seq datasets


## ----eval=FALSE,echo=TRUE------------------------------------------------
#  set_user_data(binary_matrix = myTFBSmatrix, metadata = myMetaData)

