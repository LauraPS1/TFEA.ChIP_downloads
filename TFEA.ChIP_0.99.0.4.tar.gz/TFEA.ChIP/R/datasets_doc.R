#' TF-gene binding DB metadata
#'
#' A data frame containing information of the ChIP-Seq experiments used to build the TF-gene binding DB.
#' Fields in the data frame:
#' \itemize{
#'   \item Name. Name of the file.
#'   \item Accession. Accesion ID of the experiment.
#'   \item Cell. Cell line or tissue.
#'   \item Cell.Type. More information about the cells.
#'   \item Treatment.
#'   \item Antibody.
#'   \item TF. Transcription factor tested in the ChIP-Seq experiment.
#' }
#'
#' @docType data
#' @keywords datasets
#' @name MetaData
#' @usage data(MetaData)
#' @format a list of 1129 arrays
"MetaData"

#' TF-gene binding binary matrix
#'
#' Its rows correspond to all the human genes that have been assigned an Entrez ID, and its columns, to every ChIP-Seq experiment in the database.
#' The values are 1 – if the ChIP-Seq has a peak assigned to that gene – or 0 – if it hasn’t –.
#'
#' @docType data
#' @keywords datasets
#' @name Mat01
#' @usage data(Mat01)
#' @format a matrix of 1129 columns and 23056 rows
"Mat01"


