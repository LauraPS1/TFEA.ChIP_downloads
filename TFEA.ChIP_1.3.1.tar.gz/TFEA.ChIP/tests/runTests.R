BiocGenerics:::testPackage(pkgname = "TFEA.ChIP")
